/*Só entra na festa VIP quem estiver na lista de convidados e
 trouxer convite.
Desafio:
let nome = "Joana";
let temConvite = true;
Use if/else para dizer se pode entrar ou não*/

alert ('Seu nome esta lista?')
let lisNome = prompt (`Seu nome está na lista`)
let temConvite =confirm( 'Tem convite')

if (temConvite == true && lisNome == true && lisNome == Joana){
    console.log('Pode entrar.')
}else{
    console.log('Nao pode entrar.')
}