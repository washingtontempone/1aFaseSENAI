/*Você está testando o comportamento de operadores `==` e `===`
 em uma variável string e number

let valor1 = "100";
let valor2 = 100;
```
Compare com `==` e `===`, e explique o resultado com `console.log()`.*/

let valor = String (prompt('digite um numero'))
let valor1 = 100
let valor2 = 100

if( valor1 == 100 && valor2 ===100){
    console.log ('Vai da diferencia')
}