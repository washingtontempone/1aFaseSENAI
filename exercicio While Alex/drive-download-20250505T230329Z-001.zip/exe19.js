/*Você está tentando se comunicar com um alien usando sinais booleanos.

**Desafio:**
```
let sinal1 = true;
let sinal2 = false;
```
Se ambos forem `true`, envie "Sinal de paz enviado 🛸", 
senão "Sem contato estabelecido."*/

alert('Sou o bonito')
let sinal1 = confirm('Sou bonito mesmo?')
let sinal2 = confirm('sou memso')

if (sinal1==true && sinal2== true){
    console.log("Sinal de paz enviado 🛸" ) 
}else {
    console.log('"Sem contato estabelecido."')
}