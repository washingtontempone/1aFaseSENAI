/*Um cientista decide viajar no tempo. Se o ano for menor que 2020,
 ele vai para o passado. Se for maior, vai para o futuro.
let ano;
Exiba:
"Viajando para o passado..." ou
"Rumo ao futuro!"*/

alert('Quero viajar notempo!')

let ano = Number(prompt('Em que ano quer viajar?'))

if (ano <=2020){
    console.log('Viajando pro passado!!!')
}else {
    console.log('viajem para futuro')
}
